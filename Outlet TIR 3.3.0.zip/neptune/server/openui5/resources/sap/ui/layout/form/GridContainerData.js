/*!
 * SAP UI development toolkit for HTML5 (SAPUI5/OpenUI5)
 * (c) Copyright 2009-2014 SAP AG or an SAP affiliate company. 
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
jQuery.sap.declare("sap.ui.layout.form.GridContainerData");jQuery.sap.require("sap.ui.layout.library");jQuery.sap.require("sap.ui.core.LayoutData");sap.ui.core.LayoutData.extend("sap.ui.layout.form.GridContainerData",{metadata:{library:"sap.ui.layout",properties:{"halfGrid":{type:"boolean",group:"Misc",defaultValue:false}}}});

