(function(q){var M="The file sap/ui/thirdparty/jqueryui/jquery-effects-bounce.js has been renamed to sap/ui/thirdparty/jqueryui/jquery-ui-effect-bounce.js! Please update the dependencies accordingly.";if(q&&q.sap&&q.sap.require){q.sap.require("sap.ui.thirdparty.jqueryui.jquery-ui-effect-bounce");q.sap.log.warning(M)}else{throw new Error(M)}})(window.jQuery);

