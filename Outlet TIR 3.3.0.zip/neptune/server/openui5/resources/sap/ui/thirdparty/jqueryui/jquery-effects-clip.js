(function(q){var M="The file sap/ui/thirdparty/jqueryui/jquery-effects-clip.js has been renamed to sap/ui/thirdparty/jqueryui/jquery-ui-effect-clip.js! Please update the dependencies accordingly.";if(q&&q.sap&&q.sap.require){q.sap.require("sap.ui.thirdparty.jqueryui.jquery-ui-effect-clip");q.sap.log.warning(M)}else{throw new Error(M)}})(window.jQuery);

