(function(q){var M="The file sap/ui/thirdparty/jqueryui/jquery-effects-drop.js has been renamed to sap/ui/thirdparty/jqueryui/jquery-ui-effect-drop.js! Please update the dependencies accordingly.";if(q&&q.sap&&q.sap.require){q.sap.require("sap.ui.thirdparty.jqueryui.jquery-ui-effect-drop");q.sap.log.warning(M)}else{throw new Error(M)}})(window.jQuery);

